from lifesim import Gui

Gui()